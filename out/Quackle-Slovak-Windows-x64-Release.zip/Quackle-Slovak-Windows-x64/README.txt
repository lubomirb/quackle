Quackle Slovak - Windows x64 Release

Run Quackle.exe from this folder. The data folder must remain beside the executable.
The package includes the Slovak alphabet and Slovak lexicon. To enter a blank tile,
type ? followed by the letter it represents.

If Windows reports that the Microsoft Visual C++ runtime is missing, run
vc_redist.x64.exe and then start Quackle.exe again.

The Quackle source code and GPL license are available at:
https://github.com/lubomirb/quackle
Qt third-party license information is in the licenses folder. The Slovak word list
was provided by the package recipient; its redistribution rights have not been
verified. Do not publish or redistribute it without confirming the necessary rights.